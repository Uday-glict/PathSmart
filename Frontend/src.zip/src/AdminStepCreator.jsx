// frontend/src/AdminStepCreator.jsx
import React, { useState } from 'react';
import axios from 'axios';

const BASE_URL = 'http://localhost:3000/api/admin';
const MOCK_GUIDE_ID = 101; // Use the test guide ID created in the backend setup

function AdminStepCreator() {
    const [stepData, setStepData] = useState({
        step_number: 1,
        title: 'Click the Save Button',
        content: 'Please click the blue save button to proceed to the next step.',
        target_page_url: 'http://localhost:3001/settings',
        action_type: 'tooltip',
        target_element_description: 'The primary blue save button at the bottom of the page.',
    });
    const [status, setStatus] = useState('');
    const [isLoading, setIsLoading] = useState(false);

    const handleChange = (e) => {
        setStepData({ ...stepData, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        
        setIsLoading(true);
        setStatus('Processing snapshot and AI location detection...');

        try {
            const response = await axios.post(`${BASE_URL}/guide/${MOCK_GUIDE_ID}/step`, stepData);
            
            setStatus(`✅ Success! Step created. AI Coordinates: ${response.data.coordinates}`);
            // Prepare for the next step
            setStepData(prev => ({ 
                ...prev, 
                step_number: prev.step_number + 1,
                title: '', 
                content: '',
                target_element_description: ''
            }));
        } catch (error) {
            console.error("Form Submission Error:", error.response ? error.response.data : error.message);
            setStatus(`❌ Error: ${error.response?.data?.error || error.message}. Check server console.`);
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div style={{ padding: '20px', maxWidth: '600px', margin: 'auto', fontFamily: 'sans-serif' }}>
            <h1>Admin: Create AI-Assisted Guide Step</h1>
            <p>Guide ID: **{MOCK_GUIDE_ID}** (Test Guide)</p>
            
            <form onSubmit={handleSubmit} style={{ border: '1px solid #007bff', padding: '20px', borderRadius: '8px' }}>
                <div style={{ marginBottom: '10px' }}>
                    <label>Step Number:</label>
                    <input type="number" name="step_number" value={stepData.step_number} onChange={handleChange} required disabled={isLoading} style={{ width: '100%', padding: '8px' }}/>
                </div>
                
                <div style={{ marginBottom: '10px' }}>
                    <label>Page URL:</label>
                    <input type="url" name="target_page_url" value={stepData.target_page_url} onChange={handleChange} required disabled={isLoading} style={{ width: '100%', padding: '8px' }}/>
                </div>
                
                <div style={{ marginBottom: '10px' }}>
                    <label>Display Type:</label>
                    <select name="action_type" value={stepData.action_type} onChange={handleChange} required disabled={isLoading} style={{ width: '100%', padding: '8px' }}>
                        <option value="tooltip">Tooltip</option>
                        <option value="modal">Modal</option>
                    </select>
                </div>
                
                <div style={{ marginBottom: '10px' }}>
                    <label>Step Title:</label>
                    <input type="text" name="title" value={stepData.title} onChange={handleChange} required disabled={isLoading} style={{ width: '100%', padding: '8px' }}/>
                </div>
                
                <div style={{ marginBottom: '10px' }}>
                    <label>Guide Content:</label>
                    <textarea name="content" value={stepData.content} onChange={handleChange} required disabled={isLoading} style={{ width: '100%', padding: '8px' }} rows="3"></textarea>
                </div>

                <div style={{ marginBottom: '20px', border: '1px dashed red', padding: '10px' }}>
                    <label><strong>AI Target Description (The Resilient Key)</strong>:</label>
                    <textarea 
                        name="target_element_description" 
                        placeholder="e.g., 'The big green button with the text 'Export Data''"
                        value={stepData.target_element_description} 
                        onChange={handleChange} 
                        required 
                        disabled={isLoading} 
                        rows="3"
                        style={{ width: '100%', padding: '8px' }}
                    ></textarea>
                    <small>The more descriptive, the better the AI can locate it, even if the UI shifts.</small>
                </div>

                <button type="submit" disabled={isLoading} style={{ width: '100%', padding: '10px', background: isLoading ? '#ccc' : '#28a745', color: 'white', border: 'none', borderRadius: '5px', cursor: 'pointer' }}>
                    {isLoading ? 'Processing Snapshot & AI...' : 'Create Step & Locate Element'}
                </button>
            </form>

            <p style={{ marginTop: '15px', color: status.startsWith('❌') ? 'red' : 'green' }}>{status}</p>
        </div>
    );
}

// Ensure this component is rendered in your main React file (e.g., App.jsx)
export default AdminStepCreator;