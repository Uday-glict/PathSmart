import React from 'react';
import AdminStepCreator from './AdminStepCreator';

function App() {
  return (
    <div className="App">
      <AdminStepCreator />
    </div>
  );
}

export default App;
